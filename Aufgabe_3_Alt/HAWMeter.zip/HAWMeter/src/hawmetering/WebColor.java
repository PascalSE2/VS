/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package hawmetering;


/**
 *
 * @author heitmann
 */
public class WebColor{
  public int red;
  public int green;
  public int blue;
  public int alpha;

}
