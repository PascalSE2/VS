@javax.xml.bind.annotation.XmlSchema(namespace = "http://hawmetering/")
package hawmeterproxy;
